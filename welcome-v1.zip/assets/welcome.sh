#!/bin/bash

##  This launches the about Dialog for Coopertronic OS

python /usr/share/welcome/mainwindow.py